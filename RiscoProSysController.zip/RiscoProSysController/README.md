# RISCO ProSYS SMS Controller

An offline Android app that controls a RISCO ProSYS alarm panel entirely
over SMS. No internet permission is requested anywhere in the manifest;
there is no server, no cloud account, and no API dependency. Every
setting and every event lives in local Room/EncryptedSharedPreferences
storage on the device.

## Multiple alarm systems

The app supports any number of independently-configured panels — useful if
you manage more than one branch's alarm. Each panel has its own name, GSM
number, PIN, zones, partitions, outputs, status, and history, fully
isolated from the others:

- Tap the alarm name in the Dashboard's top bar (or Settings > **Manage
  Alarm Systems**) to open the panel list.
- From there: **Switch** between panels, **rename** one, **remove** one, or
  tap **+** to add another via the same setup wizard used for the first panel.
- Incoming SMS replies are matched against *every* configured panel's GSM
  number, so a reply from Branch B updates Branch B's status/history even
  while Branch A is the one on screen.
- Each panel's PIN is stored under its own key in encrypted storage —
  switching panels never mixes up PINs between systems.

## How it works

1. You enter your panel's PIN and GSM number once, in the setup wizard.
2. Tapping a button (Arm, Disarm, bypass a zone, toggle an output...)
   builds the exact command string your panel expects (e.g. `1982 A`,
   `1982 B5`, `1982 UOON1`) and sends it via `SmsManager` — after a
   fingerprint/face/device-credential prompt for anything that changes
   panel state.
3. A `BroadcastReceiver` watches incoming SMS, checks the sender against
   your configured panel number, classifies the reply (armed / disarmed /
   alarm / power fail / battery low / etc.), and logs it to history.

## Project layout

```
app/src/main/java/com/riscoprosys/controller/
├── ui/            Compose screens + ViewModels (setup, dashboard, partitions,
│                  zones, outputs, history, settings, panels, theme)
├── database/      Room entities, DAOs, AppDatabase, type converters
├── sms/           SmsSender (outbound) and SmsReceiver (inbound)
├── security/      SecureConfigStore (encrypted PIN) and BiometricHelper
├── models/        CommandBuilder, PanelReplyParser, enums
├── repository/    AlarmRepository — the single coordination layer
└── utils/         CsvExporter, PermissionUtils
```

## Building the APK

You'll need [Android Studio](https://developer.android.com/studio)
(Koala/2024.1+ recommended) with SDK Platform 34 and the latest command-line
tools installed.

**Option A — Android Studio (recommended)**
1. `File > Open` and select this project's root folder.
2. Let Gradle sync (it will pull the exact dependency versions pinned in
   `app/build.gradle.kts` from Google's/Maven Central's servers).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. The debug APK lands in `app/build/outputs/apk/debug/app-debug.apk`.

**Option B — command line**
```bash
# From the project root, with ANDROID_HOME set:
./gradlew assembleDebug
# Signed release build (after configuring a signing config):
./gradlew assembleRelease
```
(The Gradle wrapper jar itself isn't bundled here to keep this delivery
lightweight — running `gradle wrapper` once inside Android Studio, or
`gradle wrapper --gradle-version 8.7`, regenerates `gradlew`/`gradlew.bat`
and `gradle-wrapper.jar` from the properties file already included.)

## Permissions the app requests, and why

| Permission | Why |
|---|---|
| `SEND_SMS` | Sending arm/disarm/status/zone/output commands |
| `RECEIVE_SMS`, `READ_SMS` | Reading the panel's reply to update status/history |
| `USE_BIOMETRIC` | Fingerprint/face gate before any state-changing action |

No `INTERNET` permission is present anywhere in the manifest — the app
cannot make a network call even if you wanted it to.

## Notes on the RISCO command set

The command strings implemented here (`A`, `H`, `D`, `ST`, `AL`, `A<n>`,
`D<n>`, `B<n>`, `UB<n>`, `UOON<n>`, `UOOFF<n>`) follow the syntax given in
your spec. RISCO panels are configurable per installation (language,
enabled features, exact reply wording), so if your panel's SMS replies
use different phrasing than what `PanelReplyParser` expects, adjust the
keyword lists in `models/PanelReplyParser.kt` — the panel's own SMS
programming manual (from your installer) is the authoritative reference
for your specific configuration.

## What's intentionally left as a next step

- **App lock / auto-lock after inactivity**: hook a simple idle-timer in
  `MainActivity` that navigates back to a lock screen; omitted here to
  keep the delivered scope focused on the SMS engine + screens.
- **Backup/restore of settings**: `AlarmRepository` already exposes
  everything needed (config, zones, partitions, outputs) — wire a JSON
  export/import through `CsvExporter`'s sibling for this.
- **Gradle wrapper jar**: regenerate via Android Studio as noted above
  (binary jars aren't included in this text-based delivery).
