# Keep Room entities/DAO annotations intact
-keep class com.riscoprosys.controller.database.** { *; }
-keepattributes *Annotation*

# Keep BroadcastReceiver used for SMS delivery (must not be stripped)
-keep class com.riscoprosys.controller.sms.SmsReceiver { *; }
