package com.riscoprosys.controller.models

/**
 * Interprets the free-text SMS a RISCO ProSYS panel sends back after a
 * command or on an unsolicited event (alarm, power fail, etc).
 *
 * RISCO panels are configurable in exactly which strings they send, so this
 * is intentionally keyword-based rather than a strict format match — it's
 * tolerant of minor wording differences between panel firmware/language
 * settings. Adjust the keyword lists in Settings > Panel Language if your
 * panel replies in a language other than English.
 */
object PanelReplyParser {

    fun classify(rawMessage: String): EventType {
        val msg = rawMessage.lowercase()
        return when {
            "alarm" in msg && ("triggered" in msg || "activation" in msg) -> EventType.ALARM_TRIGGERED
            "disarm" in msg -> EventType.SYSTEM_DISARMED
            "arm" in msg -> EventType.SYSTEM_ARMED
            "power" in msg && ("fail" in msg || "loss" in msg) -> EventType.POWER_FAILURE
            "battery" in msg && "low" in msg -> EventType.BATTERY_LOW
            "unbypass" in msg -> EventType.ZONE_UNBYPASSED
            "bypass" in msg -> EventType.ZONE_BYPASSED
            "output" in msg && ("on" in msg || "activ" in msg) -> EventType.OUTPUT_ACTIVATED
            "output" in msg && ("off" in msg || "deactiv" in msg) -> EventType.OUTPUT_DEACTIVATED
            "status" in msg || "ready" in msg || "not ready" in msg -> EventType.STATUS_REPLY
            else -> EventType.UNKNOWN
        }
    }

    fun toSystemStatus(eventType: EventType, previous: SystemStatus): SystemStatus = when (eventType) {
        EventType.SYSTEM_ARMED -> SystemStatus.ARMED_FULL
        EventType.SYSTEM_DISARMED -> SystemStatus.DISARMED
        EventType.ALARM_TRIGGERED -> SystemStatus.ALARM_TRIGGERED
        else -> previous
    }
}
