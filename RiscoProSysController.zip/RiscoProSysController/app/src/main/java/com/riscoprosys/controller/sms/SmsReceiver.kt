package com.riscoprosys.controller.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.riscoprosys.controller.RiscoApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Listens for every incoming SMS on the device, but only acts on messages
 * whose sender matches one of the configured panels' numbers (case- and
 * whitespace-tolerant match against each panel's stored panelPhoneNumber)
 * — this is the "verify sender" requirement, and it's what prevents a
 * spoofed/unknown sender from injecting a fake status update into history.
 * With multiple panels configured, the message is routed to whichever
 * panel's number it matches, regardless of which panel is on screen.
 *
 * Matched messages are handed to the repository, which classifies them via
 * PanelReplyParser, updates that panel's currentStatus, and appends an
 * EventLogEntity row scoped to that panel — all without any network involved.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val sender = messages[0].originatingAddress ?: return
        val body = messages.joinToString(separator = "") { it.messageBody ?: "" }

        val app = context.applicationContext as RiscoApp

        // Do work off the main thread; do NOT abort the broadcast — the
        // user's default SMS app must still receive this message normally.
        CoroutineScope(Dispatchers.IO).launch {
            app.repository.handleIncomingPanelMessage(sender, body)
        }
    }
}
