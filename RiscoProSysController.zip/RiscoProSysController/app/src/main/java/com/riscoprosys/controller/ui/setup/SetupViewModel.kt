package com.riscoprosys.controller.ui.setup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.repository.AlarmRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class SetupState(
    val alarmName: String = "",
    val panelNumber: String = "",
    val pin: String = "",
    val partitionCount: String = "1",
    val zoneCount: String = "8",
    val outputCount: String = "2",
    val isComplete: Boolean = false,
    val error: String? = null
)

class SetupViewModel(private val repository: AlarmRepository) : ViewModel() {

    private val _state = MutableStateFlow(SetupState())
    val state: StateFlow<SetupState> = _state

    fun update(transform: (SetupState) -> SetupState) {
        _state.value = transform(_state.value)
    }

    fun submit() {
        val s = _state.value
        val partitions = s.partitionCount.toIntOrNull()
        val zones = s.zoneCount.toIntOrNull()
        val outputs = s.outputCount.toIntOrNull()

        if (s.alarmName.isBlank() || s.panelNumber.isBlank() || s.pin.isBlank()) {
            _state.value = s.copy(error = "Please fill in all required fields.")
            return
        }
        if (partitions == null || zones == null || outputs == null || partitions < 1 || zones < 1 || outputs < 0) {
            _state.value = s.copy(error = "Partition, zone, and output counts must be valid numbers.")
            return
        }

        viewModelScope.launch {
            repository.completeSetup(
                alarmName = s.alarmName,
                panelNumber = s.panelNumber,
                pin = s.pin,
                partitionCount = partitions,
                zoneCount = zones,
                outputCount = outputs
            )
            _state.value = s.copy(isComplete = true, error = null)
        }
    }
}
