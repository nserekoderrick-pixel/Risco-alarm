package com.riscoprosys.controller.sms

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager

/**
 * Thin wrapper around Android's SmsManager. All commands to the panel go
 * through here so there's exactly one place that touches the radio.
 *
 * "Silent" send (per the spec) means no external SMS app UI is shown to the
 * user — SmsManager sends directly from this app after the caller has
 * already gotten user confirmation (biometric prompt + confirm dialog)
 * upstream. It does not mean hidden from the user; the app always shows
 * what was sent in the confirmation dialog and in History.
 */
class SmsSender(private val context: Context) {

    /**
     * Sends [command] to [destinationNumber] and reports delivery outcome via
     * [onResult] (true = handed off to the radio / delivered, false = failed).
     * Uses the SENT and DELIVERED broadcast pair so callers get a real
     * success/failure signal instead of assuming success once sendTextMessage
     * returns (that call is fire-and-forget).
     */
    fun sendCommand(destinationNumber: String, command: String, onResult: (Boolean) -> Unit) {
        val smsManager: SmsManager =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

        val sentAction = "${context.packageName}.SMS_SENT"
        val sentIntent = PendingIntent.getBroadcast(
            context, 0, Intent(sentAction),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val success = resultCode == android.app.Activity.RESULT_OK
                context.unregisterReceiver(this)
                onResult(success)
            }
        }
        context.registerReceiver(
            receiver, android.content.IntentFilter(sentAction),
            Context.RECEIVER_NOT_EXPORTED
        )

        val parts = smsManager.divideMessage(command)
        if (parts.size > 1) {
            val sentIntents = ArrayList<PendingIntent>().apply { repeat(parts.size) { add(sentIntent) } }
            smsManager.sendMultipartTextMessage(destinationNumber, null, parts, sentIntents, null)
        } else {
            smsManager.sendTextMessage(destinationNumber, null, command, sentIntent, null)
        }
    }
}
