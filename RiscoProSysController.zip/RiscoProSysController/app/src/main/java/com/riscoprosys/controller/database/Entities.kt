package com.riscoprosys.controller.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.riscoprosys.controller.models.EventType
import com.riscoprosys.controller.models.SystemStatus

/**
 * One row per configured alarm system. Multiple panels are supported —
 * e.g. one per branch/site — distinguished by [id]. The PIN itself is
 * deliberately NOT stored here — see security/SecureConfigStore, which
 * keys each panel's PIN by this same id — only non-secret setup data
 * lives in Room.
 */
@Entity(tableName = "alarm_config")
data class AlarmConfigEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val alarmName: String,
    val panelPhoneNumber: String,
    val partitionCount: Int,
    val zoneCount: Int,
    val outputCount: Int,
    val currentStatus: SystemStatus = SystemStatus.UNKNOWN,
    val lastUpdatedEpochMillis: Long = System.currentTimeMillis()
)

/** Every zone/partition/output/history row belongs to exactly one panel via [panelId]. */
@Entity(tableName = "zones")
data class ZoneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val panelId: Long,
    val zoneNumber: Int,
    val name: String,
    val isBypassed: Boolean = false
)

@Entity(tableName = "partitions")
data class PartitionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val panelId: Long,
    val partitionNumber: Int,
    val name: String,
    val isArmed: Boolean = false
)

@Entity(tableName = "outputs")
data class OutputEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val panelId: Long,
    val outputNumber: Int,
    val name: String,
    val isActive: Boolean = false
)

@Entity(tableName = "event_log")
data class EventLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val panelId: Long,
    val timestampEpochMillis: Long,
    val commandSent: String?,      // null for unsolicited panel messages
    val panelResponse: String?,    // raw SMS body, null if outbound only / no reply yet
    val eventType: EventType,
    val success: Boolean
)
