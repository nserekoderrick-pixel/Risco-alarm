package com.riscoprosys.controller.models

/**
 * Builds the exact SMS command strings the RISCO ProSYS panel expects.
 * Every function here returns "[PIN] [COMMAND]" — the panel's documented
 * over-SMS control syntax. Centralizing this means the rest of the app
 * never hand-assembles a command string, which keeps the format consistent
 * and easy to unit test.
 */
object CommandBuilder {

    fun fullArm(pin: String): String = "$pin A"

    fun homeArm(pin: String): String = "$pin H"

    fun fullDisarm(pin: String): String = "$pin D"

    fun status(pin: String): String = "$pin ST"

    fun alarmMemory(pin: String): String = "$pin AL"

    fun partitionArm(pin: String, partitionNumber: Int): String = "$pin A$partitionNumber"

    fun partitionDisarm(pin: String, partitionNumber: Int): String = "$pin D$partitionNumber"

    fun bypassZone(pin: String, zoneNumber: Int): String = "$pin B$zoneNumber"

    fun unbypassZone(pin: String, zoneNumber: Int): String = "$pin UB$zoneNumber"

    fun outputOn(pin: String, outputNumber: Int): String = "$pin UOON$outputNumber"

    fun outputOff(pin: String, outputNumber: Int): String = "$pin UOOFF$outputNumber"
}

/** High-level system status shown on the dashboard. */
enum class SystemStatus {
    ARMED_FULL,
    ARMED_HOME,
    DISARMED,
    ALARM_TRIGGERED,
    UNKNOWN
}

/** Classification applied to an incoming panel SMS for history + status updates. */
enum class EventType {
    SYSTEM_ARMED,
    SYSTEM_DISARMED,
    ALARM_TRIGGERED,
    POWER_FAILURE,
    BATTERY_LOW,
    ZONE_BYPASSED,
    ZONE_UNBYPASSED,
    OUTPUT_ACTIVATED,
    OUTPUT_DEACTIVATED,
    STATUS_REPLY,
    UNKNOWN
}

/** The action a user initiated from the UI — used for building the command + labeling history. */
enum class CommandAction {
    FULL_ARM, HOME_ARM, FULL_DISARM, STATUS, ALARM_MEMORY,
    PARTITION_ARM, PARTITION_DISARM,
    BYPASS_ZONE, UNBYPASS_ZONE,
    OUTPUT_ON, OUTPUT_OFF
}
