package com.riscoprosys.controller.ui.zones

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.database.ZoneEntity
import com.riscoprosys.controller.models.CommandAction
import com.riscoprosys.controller.repository.AlarmRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ZonesViewModel(private val repository: AlarmRepository) : ViewModel() {
    val zones: StateFlow<List<ZoneEntity>> = repository.observeZones()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun bypass(number: Int) = viewModelScope.launch { repository.sendCommand(CommandAction.BYPASS_ZONE, number) }
    fun unbypass(number: Int) = viewModelScope.launch { repository.sendCommand(CommandAction.UNBYPASS_ZONE, number) }
    fun rename(zone: ZoneEntity, newName: String) = viewModelScope.launch { repository.renameZone(zone, newName) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZonesScreen(
    viewModel: ZonesViewModel,
    onBack: () -> Unit,
    requireAuth: (onSuccess: () -> Unit) -> Unit
) {
    val zones by viewModel.zones.collectAsState()
    var renamingZone by remember { mutableStateOf<ZoneEntity?>(null) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Zones") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
        })
    }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(zones) { zone ->
                Card {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row {
                                Text(zone.name, style = MaterialTheme.typography.titleMedium)
                                IconButton(onClick = { renamingZone = zone }, modifier = Modifier.size(20.dp)) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Rename")
                                }
                            }
                            Text(
                                if (zone.isBypassed) "Bypassed" else "Active",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Row {
                            TextButton(onClick = { requireAuth { viewModel.bypass(zone.zoneNumber) } }) { Text("Bypass") }
                            TextButton(onClick = { requireAuth { viewModel.unbypass(zone.zoneNumber) } }) { Text("Un-bypass") }
                        }
                    }
                }
            }
        }
    }

    renamingZone?.let { zone ->
        var text by remember(zone.id) { mutableStateOf(zone.name) }
        AlertDialog(
            onDismissRequest = { renamingZone = null },
            title = { Text("Rename Zone ${zone.zoneNumber}") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.rename(zone, text)
                    renamingZone = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renamingZone = null }) { Text("Cancel") } }
        )
    }
}
