package com.riscoprosys.controller.ui.history

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.database.EventLogEntity
import com.riscoprosys.controller.repository.AlarmRepository
import com.riscoprosys.controller.utils.CsvExporter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryViewModel(private val repository: AlarmRepository) : ViewModel() {
    private val query = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val events: StateFlow<List<EventLogEntity>> = query
        .debounce(200)
        .flatMapLatest { q -> if (q.isBlank()) repository.observeHistory() else repository.searchHistory(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setQuery(q: String) { query.value = q }
    fun delete(id: Long) = viewModelScope.launch { repository.deleteHistoryItem(id) }
    fun clearAll() = viewModelScope.launch { repository.clearHistory() }

    suspend fun exportCsv(context: Context) = CsvExporter.export(context, repository.getAllHistoryOnce())
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: HistoryViewModel, onBack: () -> Unit) {
    val events by viewModel.events.collectAsState()
    var searchText by remember { mutableStateOf("") }
    var showClearConfirm by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Event History") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) } },
            actions = {
                IconButton(onClick = {
                    scope.launch {
                        val uri = viewModel.exportCsv(context)
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/csv"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Export history"))
                    }
                }) { Icon(Icons.Filled.Share, contentDescription = "Export CSV") }
                IconButton(onClick = { showClearConfirm = true }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Clear all")
                }
            }
        )
    }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it; viewModel.setQuery(it) },
                label = { Text("Search history") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(events, key = { it.id }) { event ->
                    Card {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(dateFormat.format(Date(event.timestampEpochMillis)), style = MaterialTheme.typography.labelMedium)
                                event.commandSent?.let { Text("Command: $it", style = MaterialTheme.typography.bodyMedium) }
                                event.panelResponse?.let { Text("Response: $it", style = MaterialTheme.typography.bodyMedium) }
                                Text(event.eventType.name.replace('_', ' '), style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { viewModel.delete(event.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete entry")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear all history?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { viewModel.clearAll(); showClearConfirm = false }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text("Cancel") } }
        )
    }
}
