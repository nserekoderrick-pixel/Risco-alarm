package com.riscoprosys.controller.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmConfigDao {
    @Query("SELECT * FROM alarm_config ORDER BY id ASC")
    fun observeAll(): Flow<List<AlarmConfigEntity>>

    @Query("SELECT * FROM alarm_config WHERE id = :panelId LIMIT 1")
    fun observeConfig(panelId: Long): Flow<AlarmConfigEntity?>

    @Query("SELECT * FROM alarm_config WHERE id = :panelId LIMIT 1")
    suspend fun getConfigOnce(panelId: Long): AlarmConfigEntity?

    @Query("SELECT * FROM alarm_config ORDER BY id ASC LIMIT 1")
    suspend fun getFirstOnce(): AlarmConfigEntity?

    @Query("SELECT * FROM alarm_config")
    suspend fun getAllOnce(): List<AlarmConfigEntity>

    /** Returns the generated row id — used as the new panel's id everywhere else. */
    @Insert
    suspend fun insert(config: AlarmConfigEntity): Long

    @Update
    suspend fun update(config: AlarmConfigEntity)

    @Query("DELETE FROM alarm_config WHERE id = :panelId")
    suspend fun delete(panelId: Long)

    @Query("UPDATE alarm_config SET currentStatus = :status, lastUpdatedEpochMillis = :timestamp WHERE id = :panelId")
    suspend fun updateStatus(panelId: Long, status: com.riscoprosys.controller.models.SystemStatus, timestamp: Long)

    @Query("UPDATE alarm_config SET panelPhoneNumber = :number WHERE id = :panelId")
    suspend fun updatePanelNumber(panelId: Long, number: String)

    @Query("UPDATE alarm_config SET alarmName = :name WHERE id = :panelId")
    suspend fun updateAlarmName(panelId: Long, name: String)
}

@Dao
interface ZoneDao {
    @Query("SELECT * FROM zones WHERE panelId = :panelId ORDER BY zoneNumber ASC")
    fun observeZones(panelId: Long): Flow<List<ZoneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(zones: List<ZoneEntity>)

    @Update
    suspend fun update(zone: ZoneEntity)

    @Query("UPDATE zones SET isBypassed = :bypassed WHERE panelId = :panelId AND zoneNumber = :zoneNumber")
    suspend fun setBypassed(panelId: Long, zoneNumber: Int, bypassed: Boolean)

    @Query("DELETE FROM zones WHERE panelId = :panelId")
    suspend fun deleteForPanel(panelId: Long)
}

@Dao
interface PartitionDao {
    @Query("SELECT * FROM partitions WHERE panelId = :panelId ORDER BY partitionNumber ASC")
    fun observePartitions(panelId: Long): Flow<List<PartitionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(partitions: List<PartitionEntity>)

    @Query("UPDATE partitions SET isArmed = :armed WHERE panelId = :panelId AND partitionNumber = :partitionNumber")
    suspend fun setArmed(panelId: Long, partitionNumber: Int, armed: Boolean)

    @Query("DELETE FROM partitions WHERE panelId = :panelId")
    suspend fun deleteForPanel(panelId: Long)
}

@Dao
interface OutputDao {
    @Query("SELECT * FROM outputs WHERE panelId = :panelId ORDER BY outputNumber ASC")
    fun observeOutputs(panelId: Long): Flow<List<OutputEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(outputs: List<OutputEntity>)

    @Query("UPDATE outputs SET isActive = :active WHERE panelId = :panelId AND outputNumber = :outputNumber")
    suspend fun setActive(panelId: Long, outputNumber: Int, active: Boolean)

    @Query("DELETE FROM outputs WHERE panelId = :panelId")
    suspend fun deleteForPanel(panelId: Long)
}

@Dao
interface EventLogDao {
    @Query("SELECT * FROM event_log WHERE panelId = :panelId ORDER BY timestampEpochMillis DESC")
    fun observeAll(panelId: Long): Flow<List<EventLogEntity>>

    @Query("""
        SELECT * FROM event_log
        WHERE panelId = :panelId
          AND (commandSent LIKE '%' || :query || '%' OR panelResponse LIKE '%' || :query || '%')
        ORDER BY timestampEpochMillis DESC
    """)
    fun search(panelId: Long, query: String): Flow<List<EventLogEntity>>

    @Insert
    suspend fun insert(event: EventLogEntity): Long

    @Query("DELETE FROM event_log WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM event_log WHERE panelId = :panelId")
    suspend fun clearForPanel(panelId: Long)

    @Query("SELECT * FROM event_log WHERE panelId = :panelId ORDER BY timestampEpochMillis DESC")
    suspend fun getAllOnce(panelId: Long): List<EventLogEntity>
}
