package com.riscoprosys.controller.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.database.AlarmConfigEntity
import com.riscoprosys.controller.models.CommandAction
import com.riscoprosys.controller.repository.AlarmRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DashboardViewModel(private val repository: AlarmRepository) : ViewModel() {

    val config: StateFlow<AlarmConfigEntity?> = repository.observeConfig()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _lastActionMessage = MutableStateFlow<String?>(null)
    val lastActionMessage: StateFlow<String?> = _lastActionMessage

    /** Called after the biometric gate has already succeeded upstream. */
    fun sendAction(action: CommandAction) {
        viewModelScope.launch {
            val result = repository.sendCommand(action)
            _lastActionMessage.value = if (result.isSuccess) {
                "Command sent."
            } else {
                "Failed to send command: ${result.exceptionOrNull()?.message ?: "unknown error"}"
            }
        }
    }

    fun clearMessage() {
        _lastActionMessage.value = null
    }
}
