package com.riscoprosys.controller.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.riscoprosys.controller.models.CommandAction
import com.riscoprosys.controller.models.SystemStatus
import com.riscoprosys.controller.ui.theme.StatusAlarm
import com.riscoprosys.controller.ui.theme.StatusArmed
import com.riscoprosys.controller.ui.theme.StatusDisarmed
import com.riscoprosys.controller.ui.theme.StatusUnknown

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigatePartitions: () -> Unit,
    onNavigateZones: () -> Unit,
    onNavigateOutputs: () -> Unit,
    onNavigateHistory: () -> Unit,
    onNavigateSettings: () -> Unit,
    onNavigatePanels: () -> Unit,
    /** Runs the biometric prompt, then invokes the block if auth succeeds. */
    requireAuth: (onSuccess: () -> Unit) -> Unit
) {
    val config by viewModel.config.collectAsState()
    val message by viewModel.lastActionMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    TextButton(onClick = onNavigatePanels) {
                        Icon(Icons.Filled.SwapHoriz, contentDescription = "Switch alarm system")
                        Spacer(Modifier.width(6.dp))
                        Text(config?.alarmName ?: "Select an Alarm")
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            StatusCard(status = config?.currentStatus ?: SystemStatus.UNKNOWN)

            Text("Arm / Disarm", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                BigActionButton(
                    label = "Full Arm", icon = Icons.Filled.Lock, modifier = Modifier.weight(1f),
                    onClick = { requireAuth { viewModel.sendAction(CommandAction.FULL_ARM) } }
                )
                BigActionButton(
                    label = "Home Arm", icon = Icons.Filled.House, modifier = Modifier.weight(1f),
                    onClick = { requireAuth { viewModel.sendAction(CommandAction.HOME_ARM) } }
                )
            }
            BigActionButton(
                label = "Full Disarm", icon = Icons.Filled.LockOpen,
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                onClick = { requireAuth { viewModel.sendAction(CommandAction.FULL_DISARM) } }
            )

            Text("Status", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                BigActionButton(
                    label = "Get Status", icon = Icons.Filled.Info, modifier = Modifier.weight(1f),
                    onClick = { viewModel.sendAction(CommandAction.STATUS) }
                )
                BigActionButton(
                    label = "Alarm Memory", icon = Icons.Filled.History, modifier = Modifier.weight(1f),
                    onClick = { viewModel.sendAction(CommandAction.ALARM_MEMORY) }
                )
            }

            Spacer(Modifier.height(4.dp))
            Text("Manage", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onNavigatePartitions, modifier = Modifier.weight(1f)) { Text("Partitions") }
                OutlinedButton(onClick = onNavigateZones, modifier = Modifier.weight(1f)) { Text("Zones") }
                OutlinedButton(onClick = onNavigateOutputs, modifier = Modifier.weight(1f)) { Text("Outputs") }
            }
            OutlinedButton(onClick = onNavigateHistory, modifier = Modifier.fillMaxWidth()) { Text("Event History") }
        }
    }
}

@Composable
private fun StatusCard(status: SystemStatus) {
    val (label, color) = when (status) {
        SystemStatus.ARMED_FULL -> "ARMED (FULL)" to StatusArmed
        SystemStatus.ARMED_HOME -> "ARMED (HOME)" to StatusArmed
        SystemStatus.DISARMED -> "DISARMED" to StatusDisarmed
        SystemStatus.ALARM_TRIGGERED -> "ALARM TRIGGERED" to StatusAlarm
        SystemStatus.UNKNOWN -> "STATUS UNKNOWN" to StatusUnknown
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f))
    ) {
        Row(
            modifier = Modifier.padding(24.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(Icons.Filled.Security, contentDescription = null, tint = color, modifier = Modifier.size(40.dp))
            Column {
                Text("System Status", style = MaterialTheme.typography.labelMedium)
                Text(label, style = MaterialTheme.typography.headlineSmall, color = color)
            }
        }
    }
}

@Composable
private fun BigActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(64.dp),
        colors = ButtonDefaults.buttonColors(containerColor = containerColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}
