package com.riscoprosys.controller.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.database.AlarmConfigEntity
import com.riscoprosys.controller.repository.AlarmRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PanelsUiState(
    val panels: List<AlarmConfigEntity> = emptyList(),
    val activePanelId: Long = -1L
)

class PanelsViewModel(private val repository: AlarmRepository) : ViewModel() {

    val uiState: StateFlow<PanelsUiState> = combine(
        repository.observePanels(),
        repository.currentPanelId
    ) { panels, activeId -> PanelsUiState(panels, activeId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PanelsUiState())

    fun select(panelId: Long) = repository.switchPanel(panelId)
    fun rename(panelId: Long, newName: String) = viewModelScope.launch { repository.renamePanel(panelId, newName) }
    fun delete(panelId: Long) = viewModelScope.launch { repository.deletePanel(panelId) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanelsScreen(
    viewModel: PanelsViewModel,
    onBack: () -> Unit,
    onAddPanel: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var renamingPanel by remember { mutableStateOf<AlarmConfigEntity?>(null) }
    var deletingPanel by remember { mutableStateOf<AlarmConfigEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Alarm Systems") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddPanel) { Icon(Icons.Filled.Add, contentDescription = "Add panel") }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.panels, key = { it.id }) { panel ->
                val isActive = panel.id == state.activePanelId
                Card(
                    colors = if (isActive)
                        CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    else CardDefaults.cardColors()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(panel.alarmName, style = MaterialTheme.typography.titleMedium)
                            Text(panel.panelPhoneNumber, style = MaterialTheme.typography.bodySmall)
                        }
                        Row {
                            if (isActive) {
                                Icon(Icons.Filled.Check, contentDescription = "Active", tint = MaterialTheme.colorScheme.primary)
                            } else {
                                TextButton(onClick = { viewModel.select(panel.id) }) { Text("Switch") }
                            }
                            IconButton(onClick = { renamingPanel = panel }) { Icon(Icons.Filled.Edit, contentDescription = "Rename") }
                            IconButton(onClick = { deletingPanel = panel }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                        }
                    }
                }
            }
            if (state.panels.isEmpty()) {
                item { Text("No alarm systems yet. Tap + to add one.", style = MaterialTheme.typography.bodyMedium) }
            }
        }
    }

    renamingPanel?.let { panel ->
        var text by remember(panel.id) { mutableStateOf(panel.alarmName) }
        AlertDialog(
            onDismissRequest = { renamingPanel = null },
            title = { Text("Rename Alarm") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }) },
            confirmButton = {
                TextButton(onClick = { viewModel.rename(panel.id, text); renamingPanel = null }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renamingPanel = null }) { Text("Cancel") } }
        )
    }

    deletingPanel?.let { panel ->
        AlertDialog(
            onDismissRequest = { deletingPanel = null },
            title = { Text("Remove ${panel.alarmName}?") },
            text = { Text("This deletes its zones, partitions, outputs, and history from this device. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { viewModel.delete(panel.id); deletingPanel = null }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { deletingPanel = null }) { Text("Cancel") } }
        )
    }
}
