package com.riscoprosys.controller.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.riscoprosys.controller.repository.AlarmRepository
import com.riscoprosys.controller.ui.dashboard.DashboardViewModel
import com.riscoprosys.controller.ui.history.HistoryViewModel
import com.riscoprosys.controller.ui.outputs.OutputsViewModel
import com.riscoprosys.controller.ui.panels.PanelsViewModel
import com.riscoprosys.controller.ui.partitions.PartitionsViewModel
import com.riscoprosys.controller.ui.setup.SetupViewModel
import com.riscoprosys.controller.ui.settings.SettingsViewModel
import com.riscoprosys.controller.ui.zones.ZonesViewModel

/** One small factory for every screen's ViewModel — all of them take just the repository. */
class ViewModelFactory(private val repository: AlarmRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        SetupViewModel::class.java -> SetupViewModel(repository)
        DashboardViewModel::class.java -> DashboardViewModel(repository)
        PartitionsViewModel::class.java -> PartitionsViewModel(repository)
        ZonesViewModel::class.java -> ZonesViewModel(repository)
        OutputsViewModel::class.java -> OutputsViewModel(repository)
        HistoryViewModel::class.java -> HistoryViewModel(repository)
        SettingsViewModel::class.java -> SettingsViewModel(repository)
        PanelsViewModel::class.java -> PanelsViewModel(repository)
        else -> throw IllegalArgumentException("Unknown ViewModel class: $modelClass")
    } as T
}
