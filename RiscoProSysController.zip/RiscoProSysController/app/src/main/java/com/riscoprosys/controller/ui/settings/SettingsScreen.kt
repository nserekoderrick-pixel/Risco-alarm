package com.riscoprosys.controller.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.database.AlarmConfigEntity
import com.riscoprosys.controller.repository.AlarmRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: AlarmRepository) : ViewModel() {
    val config: StateFlow<AlarmConfigEntity?> = repository.observeConfig()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun updatePanelNumber(number: String) = viewModelScope.launch { repository.updatePanelNumber(number) }
    fun updatePin(pin: String) = viewModelScope.launch { repository.updatePin(pin) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    onManageZones: () -> Unit,
    onManagePartitions: () -> Unit,
    onManageOutputs: () -> Unit,
    onManagePanels: () -> Unit,
    requireAuth: (onSuccess: () -> Unit) -> Unit
) {
    val config by viewModel.config.collectAsState()
    var panelNumber by remember(config) { mutableStateOf(config?.panelPhoneNumber ?: "") }
    var newPin by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Settings") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
        })
    }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = panelNumber,
                onValueChange = { panelNumber = it },
                label = { Text("Alarm GSM phone number") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { requireAuth { viewModel.updatePanelNumber(panelNumber) } }) {
                Text("Save Number")
            }

            Divider()

            OutlinedTextField(
                value = newPin,
                onValueChange = { newPin = it.filter(Char::isDigit) },
                label = { Text("New PIN") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { requireAuth { viewModel.updatePin(newPin); newPin = "" } }) {
                Text("Change PIN")
            }

            Divider()

            OutlinedButton(onClick = onManagePanels, modifier = Modifier.fillMaxWidth()) { Text("Manage Alarm Systems") }
            OutlinedButton(onClick = onManagePartitions, modifier = Modifier.fillMaxWidth()) { Text("Manage Partitions") }
            OutlinedButton(onClick = onManageZones, modifier = Modifier.fillMaxWidth()) { Text("Manage Zones") }
            OutlinedButton(onClick = onManageOutputs, modifier = Modifier.fillMaxWidth()) { Text("Manage Outputs") }
        }
    }
}
