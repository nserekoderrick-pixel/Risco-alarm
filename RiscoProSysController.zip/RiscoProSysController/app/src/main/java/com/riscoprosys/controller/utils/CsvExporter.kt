package com.riscoprosys.controller.utils

import android.content.Context
import androidx.core.content.FileProvider
import com.riscoprosys.controller.database.EventLogEntity
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Exports history rows to a CSV file in app-private storage, sharable via FileProvider. */
object CsvExporter {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())

    fun export(context: Context, events: List<EventLogEntity>): android.net.Uri {
        val dir = File(context.filesDir, "exports").apply { mkdirs() }
        val file = File(dir, "risco_history_${System.currentTimeMillis()}.csv")

        FileWriter(file).use { writer ->
            writer.append("Date/Time,EventType,CommandSent,PanelResponse,Success\n")
            events.forEach { e ->
                writer.append(dateFormat.format(Date(e.timestampEpochMillis))).append(',')
                writer.append(e.eventType.name).append(',')
                writer.append(csvSafe(e.commandSent ?: "")).append(',')
                writer.append(csvSafe(e.panelResponse ?: "")).append(',')
                writer.append(e.success.toString()).append('\n')
            }
        }

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    private fun csvSafe(value: String): String =
        if (value.contains(",") || value.contains("\"")) "\"${value.replace("\"", "\"\"")}\"" else value
}
