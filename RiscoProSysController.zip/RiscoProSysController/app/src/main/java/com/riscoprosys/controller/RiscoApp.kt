package com.riscoprosys.controller

import android.app.Application
import com.riscoprosys.controller.database.AppDatabase
import com.riscoprosys.controller.repository.AlarmRepository
import com.riscoprosys.controller.security.SecureConfigStore
import com.riscoprosys.controller.sms.SmsSender

/**
 * Simple manual-DI Application class. No DI framework needed for a project
 * this size — everything is wired here once and exposed as singletons.
 */
class RiscoApp : Application() {

    lateinit var repository: AlarmRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        val secureStore = SecureConfigStore(this)
        val smsSender = SmsSender(this)
        repository = AlarmRepository(
            eventLogDao = db.eventLogDao(),
            zoneDao = db.zoneDao(),
            partitionDao = db.partitionDao(),
            outputDao = db.outputDao(),
            configDao = db.alarmConfigDao(),
            secureConfigStore = secureStore,
            smsSender = smsSender
        )
        instance = this
    }

    companion object {
        lateinit var instance: RiscoApp
            private set
    }
}
