package com.riscoprosys.controller.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Security-app palette: deep navy/graphite base, amber for armed, red for alarm, green for disarmed/ready.
val StatusArmed = Color(0xFFE8A33D)
val StatusDisarmed = Color(0xFF3DDC84)
val StatusAlarm = Color(0xFFE53935)
val StatusUnknown = Color(0xFF9E9E9E)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4C7EF3),
    secondary = StatusArmed,
    tertiary = StatusDisarmed,
    background = Color(0xFF0E1116),
    surface = Color(0xFF161B22),
    error = StatusAlarm
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2952CC),
    secondary = StatusArmed,
    tertiary = StatusDisarmed,
    error = StatusAlarm
)

@Composable
fun RiscoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
