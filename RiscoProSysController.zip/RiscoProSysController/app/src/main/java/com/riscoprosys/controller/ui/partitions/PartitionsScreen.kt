package com.riscoprosys.controller.ui.partitions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.database.PartitionEntity
import com.riscoprosys.controller.models.CommandAction
import com.riscoprosys.controller.repository.AlarmRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PartitionsViewModel(private val repository: AlarmRepository) : ViewModel() {
    val partitions: StateFlow<List<PartitionEntity>> = repository.observePartitions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun arm(number: Int) = viewModelScope.launch { repository.sendCommand(CommandAction.PARTITION_ARM, number) }
    fun disarm(number: Int) = viewModelScope.launch { repository.sendCommand(CommandAction.PARTITION_DISARM, number) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartitionsScreen(
    viewModel: PartitionsViewModel,
    onBack: () -> Unit,
    requireAuth: (onSuccess: () -> Unit) -> Unit
) {
    val partitions by viewModel.partitions.collectAsState()

    Scaffold(topBar = {
        TopAppBar(title = { Text("Partitions") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, null) }
        })
    }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(partitions) { partition ->
                Card {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(partition.name, style = MaterialTheme.typography.titleMedium)
                            Text(if (partition.isArmed) "Armed" else "Disarmed", style = MaterialTheme.typography.bodySmall)
                        }
                        Row {
                            TextButton(onClick = { requireAuth { viewModel.arm(partition.partitionNumber) } }) { Text("Arm") }
                            TextButton(onClick = { requireAuth { viewModel.disarm(partition.partitionNumber) } }) { Text("Disarm") }
                        }
                    }
                }
            }
        }
    }
}
