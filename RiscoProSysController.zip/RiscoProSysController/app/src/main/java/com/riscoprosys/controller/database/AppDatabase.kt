package com.riscoprosys.controller.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        AlarmConfigEntity::class,
        ZoneEntity::class,
        PartitionEntity::class,
        OutputEntity::class,
        EventLogEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun alarmConfigDao(): AlarmConfigDao
    abstract fun zoneDao(): ZoneDao
    abstract fun partitionDao(): PartitionDao
    abstract fun outputDao(): OutputDao
    abstract fun eventLogDao(): EventLogDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "risco_prosys.db"
                )
                    // All data is local-only; no network sync ever touches this DB.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
