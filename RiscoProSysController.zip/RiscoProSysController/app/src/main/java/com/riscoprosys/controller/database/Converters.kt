package com.riscoprosys.controller.database

import androidx.room.TypeConverter
import com.riscoprosys.controller.models.EventType
import com.riscoprosys.controller.models.SystemStatus

class Converters {
    @TypeConverter
    fun fromSystemStatus(value: SystemStatus): String = value.name

    @TypeConverter
    fun toSystemStatus(value: String): SystemStatus =
        runCatching { SystemStatus.valueOf(value) }.getOrDefault(SystemStatus.UNKNOWN)

    @TypeConverter
    fun fromEventType(value: EventType): String = value.name

    @TypeConverter
    fun toEventType(value: String): EventType =
        runCatching { EventType.valueOf(value) }.getOrDefault(EventType.UNKNOWN)
}
