package com.riscoprosys.controller.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Holds the one genuinely secret value per panel: its user PIN. Backed by
 * Jetpack Security's EncryptedSharedPreferences (AES256-GCM for values,
 * AES256-SIV for keys), itself keyed by an Android Keystore-resident
 * master key that never leaves secure hardware where supported.
 *
 * Supports multiple panels: each PIN is stored under a key namespaced by
 * that panel's Room row id (see AlarmConfigEntity.id), so switching the
 * active panel never mixes up PINs between systems.
 *
 * The PIN is never written to Room, never included verbatim in exported
 * CSV history, and never logged.
 */
class SecureConfigStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "risco_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun savePin(panelId: Long, pin: String) {
        prefs.edit().putString(pinKey(panelId), pin).apply()
    }

    fun getPin(panelId: Long): String? = prefs.getString(pinKey(panelId), null)

    fun hasPin(panelId: Long): Boolean = getPin(panelId) != null

    fun clearPin(panelId: Long) {
        prefs.edit().remove(pinKey(panelId)).apply()
    }

    /** Masks a PIN for on-screen / history display, e.g. "1982" -> "••82". */
    fun mask(pin: String): String =
        if (pin.length <= 2) "•".repeat(pin.length)
        else "•".repeat(pin.length - 2) + pin.takeLast(2)

    private fun pinKey(panelId: Long) = "panel_pin_$panelId"

    // --- Remembers which panel was last selected, so the app reopens on it ---

    fun saveLastActivePanelId(panelId: Long) {
        prefs.edit().putLong(KEY_LAST_ACTIVE_PANEL, panelId).apply()
    }

    fun getLastActivePanelId(): Long? =
        prefs.getLong(KEY_LAST_ACTIVE_PANEL, -1L).takeIf { it != -1L }

    companion object {
        private const val KEY_LAST_ACTIVE_PANEL = "last_active_panel_id"
    }
}
