package com.riscoprosys.controller.ui.setup

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupWizardScreen(
    viewModel: SetupViewModel,
    onSetupComplete: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.isComplete) {
        if (state.isComplete) onSetupComplete()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Set Up Your Alarm") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Enter your RISCO ProSYS panel details. This is stored only on this device.",
                style = MaterialTheme.typography.bodyMedium)

            OutlinedTextField(
                value = state.alarmName,
                onValueChange = { v -> viewModel.update { it.copy(alarmName = v) } },
                label = { Text("Alarm name (e.g. Home Alarm)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = state.panelNumber,
                onValueChange = { v -> viewModel.update { it.copy(panelNumber = v) } },
                label = { Text("ProSYS GSM phone number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = state.pin,
                onValueChange = { v -> viewModel.update { it.copy(pin = v.filter { c -> c.isDigit() }) } },
                label = { Text("User PIN/code (e.g. 1982)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = state.partitionCount,
                    onValueChange = { v -> viewModel.update { it.copy(partitionCount = v.filter { c -> c.isDigit() }) } },
                    label = { Text("Partitions") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = state.zoneCount,
                    onValueChange = { v -> viewModel.update { it.copy(zoneCount = v.filter { c -> c.isDigit() }) } },
                    label = { Text("Zones") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = state.outputCount,
                    onValueChange = { v -> viewModel.update { it.copy(outputCount = v.filter { c -> c.isDigit() }) } },
                    label = { Text("Outputs") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Button(onClick = { viewModel.submit() }, modifier = Modifier.fillMaxWidth()) {
                Text("Finish Setup")
            }
        }
    }
}
