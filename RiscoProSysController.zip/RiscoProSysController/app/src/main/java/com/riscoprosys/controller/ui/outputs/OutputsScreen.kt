package com.riscoprosys.controller.ui.outputs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riscoprosys.controller.database.OutputEntity
import com.riscoprosys.controller.models.CommandAction
import com.riscoprosys.controller.repository.AlarmRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class OutputsViewModel(private val repository: AlarmRepository) : ViewModel() {
    val outputs: StateFlow<List<OutputEntity>> = repository.observeOutputs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun turnOn(number: Int) = viewModelScope.launch { repository.sendCommand(CommandAction.OUTPUT_ON, number) }
    fun turnOff(number: Int) = viewModelScope.launch { repository.sendCommand(CommandAction.OUTPUT_OFF, number) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OutputsScreen(
    viewModel: OutputsViewModel,
    onBack: () -> Unit,
    requireAuth: (onSuccess: () -> Unit) -> Unit
) {
    val outputs by viewModel.outputs.collectAsState()

    Scaffold(topBar = {
        TopAppBar(title = { Text("Outputs") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
        })
    }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(outputs) { output ->
                Card {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(output.name, style = MaterialTheme.typography.titleMedium)
                            Text(if (output.isActive) "Active" else "Inactive", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(
                            checked = output.isActive,
                            onCheckedChange = { checked ->
                                requireAuth {
                                    if (checked) viewModel.turnOn(output.outputNumber) else viewModel.turnOff(output.outputNumber)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
