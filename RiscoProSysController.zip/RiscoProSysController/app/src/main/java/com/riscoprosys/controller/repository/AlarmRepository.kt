package com.riscoprosys.controller.repository

import com.riscoprosys.controller.database.*
import com.riscoprosys.controller.models.*
import com.riscoprosys.controller.security.SecureConfigStore
import com.riscoprosys.controller.sms.SmsSender
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Single source of truth for the rest of the app. ViewModels never touch
 * Room, SmsSender, or SecureConfigStore directly — everything routes
 * through here.
 *
 * Supports multiple independently-configured panels (e.g. one per branch).
 * [currentPanelId] tracks which panel the UI is currently showing; every
 * observe/send function operates on that panel unless a panel id is passed
 * explicitly (as the panel picker screen does, to list all of them).
 */
class AlarmRepository(
    private val eventLogDao: EventLogDao,
    private val zoneDao: ZoneDao,
    private val partitionDao: PartitionDao,
    private val outputDao: OutputDao,
    private val configDao: AlarmConfigDao,
    private val secureConfigStore: SecureConfigStore,
    private val smsSender: SmsSender
) {
    private val _currentPanelId = MutableStateFlow(secureConfigStore.getLastActivePanelId() ?: -1L)
    val currentPanelId: StateFlow<Long> = _currentPanelId

    fun switchPanel(panelId: Long) {
        _currentPanelId.value = panelId
        secureConfigStore.saveLastActivePanelId(panelId)
    }

    // ---- Panels (multi-system support) -----------------------------------

    fun observePanels(): Flow<List<AlarmConfigEntity>> = configDao.observeAll()

    /** Config of the currently-selected panel, or null if none exist / none selected yet. */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    fun observeConfig(): Flow<AlarmConfigEntity?> =
        currentPanelId.flatMapLatest { id -> if (id <= 0) flowOf(null) else configDao.observeConfig(id) }

    suspend fun getConfigOnce(): AlarmConfigEntity? {
        val id = currentPanelId.value
        return if (id <= 0) null else configDao.getConfigOnce(id)
    }

    suspend fun hasAnyPanel(): Boolean = configDao.getFirstOnce() != null

    /** Creates a brand-new panel and makes it the active one. Returns its new id. */
    suspend fun addPanel(
        alarmName: String,
        panelNumber: String,
        pin: String,
        partitionCount: Int,
        zoneCount: Int,
        outputCount: Int
    ): Long {
        val newId = configDao.insert(
            AlarmConfigEntity(
                alarmName = alarmName,
                panelPhoneNumber = panelNumber,
                partitionCount = partitionCount,
                zoneCount = zoneCount,
                outputCount = outputCount
            )
        )
        secureConfigStore.savePin(newId, pin)
        partitionDao.upsertAll((1..partitionCount).map { PartitionEntity(panelId = newId, partitionNumber = it, name = "Partition $it") })
        zoneDao.upsertAll((1..zoneCount).map { ZoneEntity(panelId = newId, zoneNumber = it, name = "Zone $it") })
        outputDao.upsertAll((1..outputCount).map { OutputEntity(panelId = newId, outputNumber = it, name = "Output $it") })
        switchPanel(newId)
        return newId
    }

    suspend fun renamePanel(panelId: Long, newName: String) = configDao.updateAlarmName(panelId, newName)

    suspend fun deletePanel(panelId: Long) {
        configDao.delete(panelId)
        zoneDao.deleteForPanel(panelId)
        partitionDao.deleteForPanel(panelId)
        outputDao.deleteForPanel(panelId)
        eventLogDao.clearForPanel(panelId)
        secureConfigStore.clearPin(panelId)
        if (currentPanelId.value == panelId) {
            val remaining = configDao.getFirstOnce()
            _currentPanelId.value = remaining?.id ?: -1L
        }
    }

    // ---- Legacy-shaped setup entry point used by the first-run wizard -----

    suspend fun completeSetup(
        alarmName: String,
        panelNumber: String,
        pin: String,
        partitionCount: Int,
        zoneCount: Int,
        outputCount: Int
    ) = addPanel(alarmName, panelNumber, pin, partitionCount, zoneCount, outputCount)

    fun isSetupComplete(): Boolean = currentPanelId.value > 0

    suspend fun updatePin(newPin: String) {
        val id = currentPanelId.value
        if (id > 0) secureConfigStore.savePin(id, newPin)
    }

    suspend fun updatePanelNumber(number: String) {
        val id = currentPanelId.value
        if (id > 0) configDao.updatePanelNumber(id, number)
    }

    // ---- Zones / partitions / outputs (for management screens) ------------

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    fun observeZones(): Flow<List<ZoneEntity>> =
        currentPanelId.flatMapLatest { id -> if (id <= 0) flowOf(emptyList()) else zoneDao.observeZones(id) }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    fun observePartitions(): Flow<List<PartitionEntity>> =
        currentPanelId.flatMapLatest { id -> if (id <= 0) flowOf(emptyList()) else partitionDao.observePartitions(id) }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    fun observeOutputs(): Flow<List<OutputEntity>> =
        currentPanelId.flatMapLatest { id -> if (id <= 0) flowOf(emptyList()) else outputDao.observeOutputs(id) }

    suspend fun renameZone(zone: ZoneEntity, newName: String) = zoneDao.update(zone.copy(name = newName))

    // ---- History ------------------------------------------------------------

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    fun observeHistory(): Flow<List<EventLogEntity>> =
        currentPanelId.flatMapLatest { id -> if (id <= 0) flowOf(emptyList()) else eventLogDao.observeAll(id) }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    fun searchHistory(query: String): Flow<List<EventLogEntity>> =
        currentPanelId.flatMapLatest { id -> if (id <= 0) flowOf(emptyList()) else eventLogDao.search(id, query) }

    suspend fun deleteHistoryItem(id: Long) = eventLogDao.deleteById(id)
    suspend fun clearHistory() = eventLogDao.clearForPanel(currentPanelId.value)
    suspend fun getAllHistoryOnce(): List<EventLogEntity> = eventLogDao.getAllOnce(currentPanelId.value)

    // ---- Sending commands (always targets the currently-selected panel) ---

    suspend fun sendCommand(action: CommandAction, argument: Int? = null): Result<Unit> {
        val panelId = currentPanelId.value
        if (panelId <= 0) return Result.failure(IllegalStateException("No panel selected"))
        val config = configDao.getConfigOnce(panelId) ?: return Result.failure(IllegalStateException("Setup not complete"))
        val pin = secureConfigStore.getPin(panelId) ?: return Result.failure(IllegalStateException("PIN not set"))

        val command = when (action) {
            CommandAction.FULL_ARM -> CommandBuilder.fullArm(pin)
            CommandAction.HOME_ARM -> CommandBuilder.homeArm(pin)
            CommandAction.FULL_DISARM -> CommandBuilder.fullDisarm(pin)
            CommandAction.STATUS -> CommandBuilder.status(pin)
            CommandAction.ALARM_MEMORY -> CommandBuilder.alarmMemory(pin)
            CommandAction.PARTITION_ARM -> CommandBuilder.partitionArm(pin, requireNotNull(argument))
            CommandAction.PARTITION_DISARM -> CommandBuilder.partitionDisarm(pin, requireNotNull(argument))
            CommandAction.BYPASS_ZONE -> CommandBuilder.bypassZone(pin, requireNotNull(argument))
            CommandAction.UNBYPASS_ZONE -> CommandBuilder.unbypassZone(pin, requireNotNull(argument))
            CommandAction.OUTPUT_ON -> CommandBuilder.outputOn(pin, requireNotNull(argument))
            CommandAction.OUTPUT_OFF -> CommandBuilder.outputOff(pin, requireNotNull(argument))
        }
        val maskedCommand = command.replaceFirst(pin, secureConfigStore.mask(pin))

        val success = sendViaRadio(config.panelPhoneNumber, command)

        eventLogDao.insert(
            EventLogEntity(
                panelId = panelId,
                timestampEpochMillis = System.currentTimeMillis(),
                commandSent = maskedCommand,
                panelResponse = null,
                eventType = expectedEventType(action),
                success = success
            )
        )

        applyOptimisticLocalState(panelId, action, argument)

        return if (success) Result.success(Unit) else Result.failure(IllegalStateException("SMS send failed"))
    }

    private suspend fun sendViaRadio(number: String, command: String): Boolean =
        suspendCancellableCoroutine { cont ->
            smsSender.sendCommand(number, command) { result ->
                if (cont.isActive) cont.resume(result)
            }
        }

    private suspend fun applyOptimisticLocalState(panelId: Long, action: CommandAction, argument: Int?) {
        when (action) {
            CommandAction.PARTITION_ARM -> argument?.let { partitionDao.setArmed(panelId, it, true) }
            CommandAction.PARTITION_DISARM -> argument?.let { partitionDao.setArmed(panelId, it, false) }
            CommandAction.BYPASS_ZONE -> argument?.let { zoneDao.setBypassed(panelId, it, true) }
            CommandAction.UNBYPASS_ZONE -> argument?.let { zoneDao.setBypassed(panelId, it, false) }
            CommandAction.OUTPUT_ON -> argument?.let { outputDao.setActive(panelId, it, true) }
            CommandAction.OUTPUT_OFF -> argument?.let { outputDao.setActive(panelId, it, false) }
            else -> Unit
        }
    }

    private fun expectedEventType(action: CommandAction): EventType = when (action) {
        CommandAction.FULL_ARM, CommandAction.HOME_ARM, CommandAction.PARTITION_ARM -> EventType.SYSTEM_ARMED
        CommandAction.FULL_DISARM, CommandAction.PARTITION_DISARM -> EventType.SYSTEM_DISARMED
        CommandAction.BYPASS_ZONE -> EventType.ZONE_BYPASSED
        CommandAction.UNBYPASS_ZONE -> EventType.ZONE_UNBYPASSED
        CommandAction.OUTPUT_ON -> EventType.OUTPUT_ACTIVATED
        CommandAction.OUTPUT_OFF -> EventType.OUTPUT_DEACTIVATED
        CommandAction.STATUS -> EventType.STATUS_REPLY
        CommandAction.ALARM_MEMORY -> EventType.STATUS_REPLY
    }

    // ---- Incoming panel messages (called from SmsReceiver) -----------------

    /**
     * Matches the sender against every configured panel's number (not just
     * the currently-displayed one) so a reply from Branch B's panel is
     * still logged correctly even while Branch A's panel is on screen.
     */
    suspend fun handleIncomingPanelMessage(senderNumber: String, rawBody: String) {
        val allPanels = configDao.getAllOnce()
        val matched = allPanels.firstOrNull { numbersMatch(senderNumber, it.panelPhoneNumber) } ?: return

        val eventType = PanelReplyParser.classify(rawBody)
        val newStatus = PanelReplyParser.toSystemStatus(eventType, matched.currentStatus)

        configDao.updateStatus(matched.id, newStatus, System.currentTimeMillis())

        eventLogDao.insert(
            EventLogEntity(
                panelId = matched.id,
                timestampEpochMillis = System.currentTimeMillis(),
                commandSent = null,
                panelResponse = rawBody,
                eventType = eventType,
                success = true
            )
        )
    }

    private fun numbersMatch(a: String, b: String): Boolean {
        fun normalize(n: String) = n.filter { it.isDigit() }.takeLast(9)
        val na = normalize(a)
        val nb = normalize(b)
        return na.isNotEmpty() && na == nb
    }
}
