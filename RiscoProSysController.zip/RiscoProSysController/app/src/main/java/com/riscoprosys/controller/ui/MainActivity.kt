package com.riscoprosys.controller.ui

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.riscoprosys.controller.RiscoApp
import com.riscoprosys.controller.security.BiometricHelper
import com.riscoprosys.controller.ui.dashboard.DashboardScreen
import com.riscoprosys.controller.ui.dashboard.DashboardViewModel
import com.riscoprosys.controller.ui.history.HistoryScreen
import com.riscoprosys.controller.ui.history.HistoryViewModel
import com.riscoprosys.controller.ui.outputs.OutputsScreen
import com.riscoprosys.controller.ui.outputs.OutputsViewModel
import com.riscoprosys.controller.ui.panels.PanelsScreen
import com.riscoprosys.controller.ui.panels.PanelsViewModel
import com.riscoprosys.controller.ui.partitions.PartitionsScreen
import com.riscoprosys.controller.ui.partitions.PartitionsViewModel
import com.riscoprosys.controller.ui.setup.SetupViewModel
import com.riscoprosys.controller.ui.setup.SetupWizardScreen
import com.riscoprosys.controller.ui.settings.SettingsScreen
import com.riscoprosys.controller.ui.settings.SettingsViewModel
import com.riscoprosys.controller.ui.theme.RiscoTheme
import com.riscoprosys.controller.ui.zones.ZonesScreen
import com.riscoprosys.controller.ui.zones.ZonesViewModel
import com.riscoprosys.controller.utils.PermissionUtils

/**
 * Single-activity host for the whole Compose navigation graph. Uses
 * FragmentActivity (not ComponentActivity) because BiometricPrompt requires it.
 */
class MainActivity : FragmentActivity() {

    private val factory by lazy { ViewModelFactory((application as RiscoApp).repository) }
    private lateinit var biometricHelper: BiometricHelper

    private val requestSmsPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* Dashboard re-checks state on next command attempt regardless of result. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        biometricHelper = BiometricHelper(this)

        if (!PermissionUtils.hasAllRequired(this)) {
            requestSmsPermissions.launch(PermissionUtils.REQUIRED_PERMISSIONS)
        }

        val repository = (application as RiscoApp).repository

        setContent {
            RiscoTheme {
                val navController = rememberNavController()
                var startDestination by remember {
                    mutableStateOf(if (repository.isSetupComplete()) "dashboard" else "setup")
                }

                fun requireAuth(onSuccess: () -> Unit) {
                    if (biometricHelper.canAuthenticate()) {
                        biometricHelper.authenticate(
                            title = "Confirm it's you",
                            subtitle = "Authenticate to control your alarm system",
                            onSuccess = onSuccess,
                            onFailure = { /* Show inline error via snackbar in a fuller build */ }
                        )
                    } else {
                        // No biometric/device credential enrolled at all — fail safe by
                        // still requiring the action to be an explicit, deliberate tap
                        // (already true), but note this in Settings so the user can
                        // enroll a credential for full protection.
                        onSuccess()
                    }
                }

                AppNavHost(
                    navController = navController,
                    startDestination = startDestination,
                    factory = factory,
                    requireAuth = ::requireAuth
                )
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun AppNavHost(
    navController: NavHostController,
    startDestination: String,
    factory: ViewModelFactory,
    requireAuth: (onSuccess: () -> Unit) -> Unit
) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable("setup") {
            val vm: SetupViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            SetupWizardScreen(viewModel = vm, onSetupComplete = {
                navController.navigate("dashboard") { popUpTo("setup") { inclusive = true } }
            })
        }
        // Reuses the same wizard UI to add an additional panel; returns to the
        // Panels list afterward instead of replacing the whole back stack.
        composable("add_panel") {
            val vm: SetupViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            SetupWizardScreen(viewModel = vm, onSetupComplete = {
                navController.popBackStack()
            })
        }
        composable("dashboard") {
            val vm: DashboardViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            DashboardScreen(
                viewModel = vm,
                onNavigatePartitions = { navController.navigate("partitions") },
                onNavigateZones = { navController.navigate("zones") },
                onNavigateOutputs = { navController.navigate("outputs") },
                onNavigateHistory = { navController.navigate("history") },
                onNavigateSettings = { navController.navigate("settings") },
                onNavigatePanels = { navController.navigate("panels") },
                requireAuth = requireAuth
            )
        }
        composable("partitions") {
            val vm: PartitionsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            PartitionsScreen(viewModel = vm, onBack = { navController.popBackStack() }, requireAuth = requireAuth)
        }
        composable("zones") {
            val vm: ZonesViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            ZonesScreen(viewModel = vm, onBack = { navController.popBackStack() }, requireAuth = requireAuth)
        }
        composable("outputs") {
            val vm: OutputsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            OutputsScreen(viewModel = vm, onBack = { navController.popBackStack() }, requireAuth = requireAuth)
        }
        composable("history") {
            val vm: HistoryViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            HistoryScreen(viewModel = vm, onBack = { navController.popBackStack() })
        }
        composable("settings") {
            val vm: SettingsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            SettingsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onManageZones = { navController.navigate("zones") },
                onManagePartitions = { navController.navigate("partitions") },
                onManageOutputs = { navController.navigate("outputs") },
                onManagePanels = { navController.navigate("panels") },
                requireAuth = requireAuth
            )
        }
        composable("panels") {
            val vm: PanelsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
            PanelsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onAddPanel = { navController.navigate("add_panel") }
            )
        }
    }
}
